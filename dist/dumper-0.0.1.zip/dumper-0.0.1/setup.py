import os
from setuptools import setup

setup(
    name = "dumper",
    version = "0.0.1",
    author = "yattom",
    author_email = "tsutomu.yasui@gmail.com",
    packages = ['dumper']
)
